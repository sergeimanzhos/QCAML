function params = simulinkParameters(s,param)
%

% Copyright 2012 The MathWorks, Inc.

params = {};
