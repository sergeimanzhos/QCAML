function s = isScalar
%

% Copyright 2012 The MathWorks, Inc.

s = true;
