function flag = discontinuity(n,param)
%

% Copyright 2012 The MathWorks, Inc.

flag = false(1,size(n,2));


