function param = parameterInfo
%

% Copyright 2012 The MathWorks, Inc.

param = [];
