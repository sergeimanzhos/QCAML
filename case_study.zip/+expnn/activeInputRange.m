function ir = activeInputRange
%

% Copyright 2012 The MathWorks, Inc.

ir = [-2 2];
