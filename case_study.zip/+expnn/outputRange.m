function or = outputRange
%

% Copyright 2012 The MathWorks, Inc.

or = [0 1000];
